import random

from faker import Faker
fake = Faker(locale='zh-CN')


def func_yaml(data):
    # 判断data数据类型为字典
    if isinstance(data, dict):
        # 把data.yaml里面key，value都循环一遍
        for key, value in data.items():
            # 判断random里面有没有值如果有重新赋值给data[key]，用eval,age要强制转换字符串
            if '${' and '}' in str(value):
                start = str(value).index('${')  # 从3开始到18结束
                end = str(value).index('}')
                # if 'random' in str(value):
                func_name = str(value)[start + 2:end]
                data[key] = str(value)[0:start] + str(eval(func_name)) + str(value)[end+1:len(str(value))]
    return data


def random_name():
    return fake.name()


def age():
    return random.randint(10, 100)


if __name__ == '__main__':
    data = {'name': '上海-${random_name()}-测试', 'age': '${age()}', 'sex': '男'}
    print(func_yaml(data))
