import os

import yaml


class YamlUtil:
    def __init__(self):
        self.data_path = os.path.join(os.path.dirname(os.path.dirname(os.path.realpath(__file__))), "data/")

    def read_extract_yaml(self):
        with open(self.data_path + "extract.yaml", mode='r', encoding='utf8') as f:
            value = yaml.safe_load(f)
            return value

    # 读yaml的方法
    def read_testcase_yaml(self, yaml_name, key_name=None):
        with open(self.data_path + yaml_name, mode='r', encoding='utf8') as f:
            value = yaml.safe_load(f)
            if key_name:
                return value[key_name]
            return value

    def extract_case(self, yaml_name, key_name):
        case_value = self.read_testcase_yaml(yaml_name, key_name)[0]
        new_case = []
        for value in case_value['case_info']:
            new_case.append({"request_info": case_value['request_info'], "case_info": value})
        return new_case

    # 写extract_yaml的方法mode-a末尾追加模式w是覆盖之前的数据重新写入
    def write_extra_yaml(self, data):
        with open(self.data_path + "extract.yaml", mode='a', encoding='utf8') as f:
            # 获取extract.yaml的内容
            old_value = self.read_extract_yaml()
            if old_value:
                # 和新传入的数据做结合
                for key, value in data.items():
                    # 判断旧的值跟新值是否一样
                    old_value[key] = value
                # 清空数据
                self.clear_extract_yaml()
                yaml.dump(data=old_value, stream=f, allow_unicode=True, sort_keys=False)
            else:
                yaml.dump(data=data, stream=f, allow_unicode=True, sort_keys=False)

    def clear_extract_yaml(self):
        """清理extract_yaml"""
        with open(self.data_path + "extract.yaml", mode='w', encoding='utf8') as f:
            f.truncate()


if __name__ == '__main__':
    # data = YamlUtil().extract_case('user_center.yaml', 'user_loggin_new')
    # print(data)
    data = {"code": 100, "data": {"id": 3386, "addres": "测试大道"}}
    YamlUtil().write_extra_yaml(data)
    # print(YamlUtil().read_extract_yaml())