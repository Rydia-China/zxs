import os
import yaml
import configparser

# 找到data文件和ini文件的路径
data_path = os.path.join(os.path.dirname(os.path.dirname(os.path.realpath(__file__))), "data", "data.yaml")
ini_path = os.path.join(os.path.dirname(os.path.dirname(os.path.realpath(__file__))), "config", "settings.ini")
file_path = os.path.join(os.path.dirname(os.path.dirname(os.path.realpath(__file__))), "file", "tu.png")


# 读取yaml文件和ini文件的方法
class FileRead:
    def __init__(self):
        self.data_path = data_path
        self.ini_path = ini_path
        self.file_path = file_path

    def read_data(self):
        f = open(self.data_path, encoding="utf8")
        data = yaml.safe_load(f)
        return data

    def read_ini(self):
        config = configparser.ConfigParser()
        config.read(self.ini_path, encoding='utf8')
        return config

    def read_file(self):
        file = open(self.file_path, 'rb')
        # request里面files参数，读取key+文件名,读取文件流(read里),Content-Type:
        return {'file': ('tu.png', file, 'image/jpeg')}


base_data = FileRead()
