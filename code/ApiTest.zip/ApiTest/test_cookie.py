import requests

# # 创建一个会话
# req = requests.Session()
#
# url = 'http://sellshop.5istudy.online/sell/user/login'
# data = {
#     "username": 'test01',
#     "password": '123456'
# }
#
# # 登录，req保存了cookie或者session
# res = req.post(url, data=data)
# # print(res.text)
#
# url2 = 'http://sellshop.5istudy.online/sell/seller/order/list?page=2&size=10'
#
# res2 = req.get(url2)
# print(res2.text)


# 如果不创建一个session 就需要加一个headers添加cookie
headers = {
    'Cookie': 'token=11b21c49-751c-4dea-a95e-3192066892af'
}

url2 = 'http://sellshop.5istudy.online/sell/seller/order/list?page=2&size=10'

res2 = requests.get(url=url2, headers=headers)
print(res2.text)