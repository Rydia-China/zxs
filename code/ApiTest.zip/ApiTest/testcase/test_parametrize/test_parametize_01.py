import pytest


# 单参数单次循环
# @pytest.mark.parametrize("name",["大东"])
# def test_parametrize(name):
#     print("我是"+ name)

# 单参数多次循环
# 运行时将数组里的词分别赋值给变量，每赋值一次，运行一次
# 有几个值，测试用例执行几次
# @pytest.mark.parametrize("name", ["貂蝉", "大乔", "小乔"])
# def test_parametrize(name):
#     assert name == "貂蝉"


# 参数值为字典
@pytest.mark.parametrize("hero", [{"name": "貂蝉", "word": "我要吃桃子"}, {"name": "大乔", "word": "我要吃西瓜"}, {"name": "小乔", "word": "我要吃苹果"}])
def test_parametrize(hero):
    print(hero["name"])
    print(hero["word"])



