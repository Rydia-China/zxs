import pytest

# 数组的形式
# @pytest.mark.parametrize("name,word", [["貂蝉", "我吃西瓜"], ["大乔", "我吃香蕉"], ["小乔", "我吃桃子"]])
# def test_parametrize_02(name, word):
#     print(f'{name}说“{word}”')

# 元组的形式
@pytest.mark.parametrize("name,word", [("貂蝉", "我吃西瓜"), ("大乔", "我吃香蕉"), ("小乔", "我吃桃子")])
def test_parametrize_02(name, word):
    print(f'{name}说“{word}”')

@pytest.mark.parametrize("name,word", [["貂蝉", "我吃西瓜"]])
def test_parametrize_02(name, word):
    print(f'{name}说“{word}”')
