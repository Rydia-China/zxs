import pytest
from utils.read_data import get_data
from utils.yaml_util import func_yaml


# def test_person():
#     data = get_data["person"]
#     print(func_yaml(data))

# data_yaml字典形式用get_data,数组的话用parametrize
@pytest.mark.parametrize("data", get_data["person"])
def test_person(data):
    print(func_yaml(data))


if __name__ == '__main__':
    pytest.main()
