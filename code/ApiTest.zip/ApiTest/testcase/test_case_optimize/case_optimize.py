import pytest
import requests
from api.api import mobile_query
from core.rest_client import Api
from utils.read import base_data
from utils.response_util import process_response

url = base_data.read_ini()['host']['api_sit_url']


# 测试用例
def test_mobile():
    # print("测试手机号码归属地get请求")
    # r = requests.get(url + '/shouji/query',
    #                  params={"shouji": param['shouji'], "appkey": param['appkey']})
    #
    # print(r.status_code)
    # assert r.status_code == 200
    # result = r.json()
    param = base_data.read_data()["mobile_belong"]
    result = mobile_query(param)
    # result = Api.get("/shouji/query", params=param)
    assert result.success is True
    assert result.body['status'] == 0
    assert result.body['msg'] == 'ok'
    assert result.body['result']['shouji'] == '13456755448'
    assert result.body['result']['province'] == '浙江'
    assert result.body['result']['city'] == '杭州'
    assert result.body['result']['company'] == '中国移动'
    assert result.body['result']['cardtype'] is None
    assert result.body['result']['areacode'] == '0571'


if __name__ == '__main__':
    pytest.main()
