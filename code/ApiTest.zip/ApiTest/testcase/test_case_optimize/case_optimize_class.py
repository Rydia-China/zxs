import allure
import pytest
import requests
from api.api import mobile_query
from core.rest_client import Api
from utils.read import base_data
from utils.response_util import process_response

url = base_data.read_ini()['host']['api_sit_url']


@allure.epic("数据进制项目epic")
@allure.feature("手机号模块feature")
class TestMobile:
    # 测试用例
    @allure.story("杭州手机号story")
    @allure.title("测试手机号归属地title")
    @allure.testcase("http://www.baidu.com", name="接口地址testcases")
    @allure.issue("http://www.baidu.com", name="缺陷地址issue")
    @allure.description("当前手机号是13456755448，归属地是杭州的description")
    @allure.link("http://www.baidu.com", name="链接地址link")
    @allure.step("现金归属地的操作step")
    @allure.severity(severity_level="critical")  # 用例等级
    def test_mobile(slef):
        param = base_data.read_data()["mobile_belong"]
        result = mobile_query(param)
        assert result.success is True
        assert result.body['status'] == 0
        assert result.body['msg'] == 'ok'
        assert result.body['result']['shouji'] == '13456755448'
        assert result.body['result']['province'] == '浙江'
        assert result.body['result']['city'] == '杭州'
        assert result.body['result']['company'] == '中国移动'
        assert result.body['result']['cardtype'] is None
        assert result.body['result']['areacode'] == '0571'

    @allure.story("杭州手机号story")
    @allure.title("测试手机号归属地title")
    @allure.testcase("http://www.baidu.com", name="接口地址testcases")
    @allure.issue("http://www.baidu.com", name="缺陷地址issue")
    @allure.description("当前手机号是13456755448，归属地是杭州的description")
    @allure.link("http://www.baidu.com", name="链接地址link")
    @allure.step("现金归属地的操作step")
    @allure.severity(severity_level="critical")  # 用例等级
    def test_mobile_dynamic(slef):
        param = base_data.read_data()["mobile_belong_dynamic"]['params']
        title = base_data.read_data()["mobile_belong_dynamic"]['title']
        story = base_data.read_data()["mobile_belong_dynamic"]['story']
        allure.dynamic.title(title)
        allure.dynamic.story(story)
        result = mobile_query(param)
        assert result.success is True
        assert result.body['status'] == 0
        assert result.body['msg'] == 'ok'
        assert result.body['result']['shouji'] == '13456755448'
        assert result.body['result']['province'] == '浙江'
        assert result.body['result']['city'] == '杭州'
        assert result.body['result']['company'] == '中国移动'
        assert result.body['result']['cardtype'] is None
        assert result.body['result']['areacode'] == '0571'


if __name__ == '__main__':
    pytest.main()
