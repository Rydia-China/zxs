import pytest
from api.api import json_test
from utils.read import base_data
from utils.log_util import logger


# 测试用例
def test_post():
    json_data = base_data.read_data()['json_data']
    result = json_test(json_data)
    assert result['id'] == 101


if __name__ == '__main__':
    pytest.main()


