#用户名密码登录
#拿到登录token，获取用户信息
import token
import pytest

import requests

class TestUser:
    #类属性调用
    token_1 = ""
    username_1 = ""

    def test_login(self):
        username = 'dadong'
        password = '123456'
        #res = requests.post("/login",json={"username":username,"passwrod":password})
        token = "token"

        assert  token == "token"
        #return token,unername
        TestUser.token_1 = token
        TestUser.username_1 = username


    def test_userinfo(self):
        #token, username= self.test_login()
        headers = {
            "token": TestUser.token_1
        }
        #res = requests.post('/get_user',headers=headers)
        assert  headers['token'] == TestUser.token_1
        assert  TestUser.username_1 == 'dadong'

if __name__ == '__main__':
        pytest.main()