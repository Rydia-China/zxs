import json
import requests
from core.api_util import api_util
from utils.log_util import logger
from utils.response_util import process_response


# 使用方法传参数
def mobile_query(params):
    # r = requests.get(url + '/shouji/query',
    #                  params={"shouji": param['shouji'], "appkey": param['appkey']})

    # assert r.status_code == 200
    # r = get_mobile_belong(params=params)

    response = api_util.get_mobile_belong(params=params)
    result = process_response(response)
    # logger.info('接口的返回内容>>' + json.dumps(response.json(), ensure_ascii=False))
    return result
    # print(r.status_code)
    # result = r.json()
    # return result


def json_test(json_data):
    """
    这个方法测试json传参
    :param json_data:
    :return:
    """
    response = api_util.post_data(json=json_data)
    process_response(response)
    return response.json()
