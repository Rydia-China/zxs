from core.rest_client import RestClient


# 存放测试接口地址
class Api(RestClient):

    # 初始化
    def __init__(self):
        super().__init__()

    def get_mobile_belong(self, **kwargs):
        return self.get("/shouji/query", **kwargs)

    def post_data(self, **kwargs):
        return self.post("/posts", **kwargs)

    # 获取验证码
    def get_code(self, **kwargs):
        return self.post("/code/", **kwargs)

    # 注册
    def register_mobile(self, **kwargs):
        return self.post("/users/", **kwargs)

    # 登录
    def user_login(self, **kwargs):
        return self.post("/login/", **kwargs)

    # 加入购物车
    def shopping_add(self, **kwargs):
        return self.post("/shopcarts/", **kwargs)

    # 新增留言
    def add_massage(self, **kwargs):
        return self.post("/messages/", **kwargs)

    # 添加地址
    def add_address(self, **kwargs):
        return self.post("/address/", **kwargs)

    # 更新收货地址
    def update_address(self, **kwargs):
        return self.put("/address/105988/", **kwargs)

    # 添加地址
    def submit_order(self, **kwargs):
        return self.post("/orders/", **kwargs)

    # banner
    def banner(self, **kwargs):
        return self.get("/banners/", **kwargs)


api_util = Api()
