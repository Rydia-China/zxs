# 用来组装response
class ResultResponse:
    pass
