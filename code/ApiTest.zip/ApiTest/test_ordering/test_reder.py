class TestPay:

    def test_login(slfe):
        print('login...')

    def test_search(slfe):
        print('search...')

    def test_order(slfe):
        print('order...')

    def test_pay(slfe):
        print('pay...')

