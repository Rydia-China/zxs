def test_rule():
    assert 1 == 1
