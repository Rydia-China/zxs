class TestRule:
    def test_rule(self):
        assert 1 == 1

    def test_rule2(self):
        assert 1 == 2
