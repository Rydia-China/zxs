import os

import pytest
from api.user_api import login
from utils.read import base_data


# 将base_data.read_data()作为一个关键字
def get_data():
    return base_data.read_data()


@pytest.fixture(scope="session")
# 定义一个login_fixture用作每一个接口都可以访问当前的token,function调用
def login_fitxture():
    if 'token' not in os.environ:
        data = get_data()['login_fixture']
        mobile = data['mobile']
        password = data['password']
        # 登录接口
        result = login(mobile, password)
        # 用os模块将token,mobile作为临时变量存放在环境中,只能存str类型
        os.environ['token'] = result.body['token']
        os.environ['mobile'] = str(mobile)
        # 返回token 还有mobile
        return result.body['token'], mobile
    else:
        return os.environ['token'], os.environ['mobile']


# 使用fixture.session减少调用
@pytest.fixture(scope="session")
def login_token():
    data = get_data()['login_fixture']
    mobile = data['mobile']
    password = data['password']
    # 登录接口
    result = login(mobile, password)
    # headers 组装放到这里user_api里面就不需要写headers
    headers = {
        "Authorization": "JWT " + result.body['token']
    }
    # 返回token 还有mobile
    return headers
