import allure
import pytest
from api.user_api import send_code, register, login, add_shopping_cart, add_message, add_shopping_cart2, add_message2, \
    add_address, submit_order, update_address
from testcases.conftest import get_data
from testcases.usercenter.conftest import get_code, delete_user, delete_code, get_shop_cart_num
from utils.read import base_data


# 测试用例集
@allure.feature("用户中心模块")
class TestUser:
    mobile = None

    # 注册
    @allure.story("用户注册后登录")
    @allure.title("注册手机号测试用例")
    def test_register(self):
        # 读data的yaml文件，test_register这个字典
        json_data = get_data()['test_register']
        # 删除验证码，以防每次都提示
        delete_code(json_data['mobile'])
        # 发送验证码
        result = send_code(json_data)
        assert result.success is True
        # 获取短信验证码
        mobile = result.body['mobile']
        code = get_code(mobile)
        # 注册
        register_result = register(code, mobile)
        assert register_result.success is True
        # 删除用户
        delete_user(mobile)

    # 登录测试用例
    @pytest.mark.parametrize("username,password", get_data()['user_login'])
    @allure.story("用户登录")
    @allure.title("用户手机号登录")
    def test_login(self, username, password):
        print(username, password)
        TestUser.mobile = username
        result = login(username, password)
        assert result.success is True
        assert len(result.body['token']) != 0

    # @pytest.mark.parametrize("username,password", get_data()['user_login'])
    # def test_shopping_cart(self, username, password):
    #     # 登录接口
    #     result = login(username, password)
    #     token = result.body['token']
    # 添加购物车
    @allure.story("购物车相关")
    @allure.title("加购物车")
    def test_shopping_cart(self, login_fitxture):
        # 下标0第一个值获取token
        token = login_fitxture[0]
        # 下标1第2个值获取mobile
        username = login_fitxture[1]
        param = get_data()['shopping_cart']
        result = add_shopping_cart(param, token)
        # 查询购物车数量
        num = get_shop_cart_num(username, param['goods'])
        assert result.success is True
        assert result.body['nums'] == num

    @allure.story("留言板")
    @allure.title("留言板上传文件")
    def test_add_message(self, login_fitxture):
        token = login_fitxture[0]
        data = get_data()['add_message']
        files = base_data.read_file()
        result = add_message(data, files, token)
        assert result.success is True
        assert result.body['subject'] == data['subject']

    @allure.story("收货地址")
    @allure.title("添加收货地址")
    def test_add_address(self, login_token):
        data = get_data()['add_address']
        result = add_address(data, login_token)
        assert result.success is True

    @allure.story("订单中心")
    @allure.title("提交订单")
    def test_submit_order(self, login_token):
        data = get_data()['submit_order']
        result = submit_order(data, login_token)
        assert result.success is True

    @allure.story("收货地址")
    @allure.title("更新收获地址")
    def test_update_address(self, login_token):
        data = get_data()['update_address']
        result = update_address(data, login_token)
        assert result.success is True

    @allure.story("购物车相关")
    @allure.title("加购物车")
    def test_shopping_cart2(self, login_token):
        param = get_data()['shopping_cart']
        result = add_shopping_cart2(param, login_token)
        # 查询购物车数量,通过类变量去访问mobile
        num = get_shop_cart_num(TestUser.mobile, param['goods'])
        assert result.success is True
        assert result.body['nums'] == num

    @allure.story("留言板")
    @allure.title("留言板上传文件")
    def test_add_message2(self, login_token):
        data = get_data()['add_message']
        files = base_data.read_file()
        result = add_message2(data, files, login_token)
        assert result.success is True
        assert result.body['subject'] == data['subject']


if __name__ == '__main__':
    pytest.main()
